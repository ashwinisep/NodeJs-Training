const mongoose = require("mongoose")

//Define the Users Model named "UserModel"
mongoose.model('UserModel' , {
    name:{
        type: String,
        required: true
    },
    _userid: {
        type: Number,
        required: true
    },
    get userid() {
        return this._userid
    },
    set userid(value) {
        this._userid = value
    },
    email :{
        type: String,
        required: true
    }
})