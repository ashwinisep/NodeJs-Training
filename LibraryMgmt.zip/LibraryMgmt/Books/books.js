//load express framework
const express= require('express');
const  app= express();
const mongoose = require('mongoose');

const bodyparser = require("body-parser");

app.use(bodyparser.json());

//Load Book model data
require('./Book');

const BookModel = mongoose.model("Book") ; //Load the Book model data
mongoose.connect("mongodb+srv://mongodb:Cel%401234@cluster0.envdo.mongodb.net/BooksService" , { useNewUrlParser: true, useUnifiedTopology: true }, ()=>{ 
  console.log("BooksService database connected successfully");
});

app.get('/', (req,res) => {

    res.end("Our books endpoint");
})

//Book  to insert entries for books
app.post("/book" , (req,res) => {

  //console.log(req.body); //print the request sent
  //res.send("book:Testing book route");

  //Store the book fields in a variable named 'BookDetails  
  var BookDetails = { 
  
    title : req.body.title,
    author : req.body.author,
    NumOfPages:req.body.NumOfPages,
    publisher:req.body.publisher
  }

  
  //Create a new Book instance and save it in Bookinst 
  var BookInst= new BookModel(BookDetails);
  
  //Save the Bookinst  
    BookInst.save(function (err, data) {
        console.log("New book created and saved");
      })/* .catch((err) => {
     if(err)
     {
          console.log("Error in book creation");
           throw err;
     }
      
  })*/
  res.send("Response - Book created successfully");//send the response back
})

//List all the books from DB
app.get("/books",(req,res)=>{
  //Call Model
  BookModel.find().then( (books)=>{
    //console.log(books)
    res.json(books);//show the json content in the web page http://localhost:4545/books
  }).catch(err =>{
         if(err)
          throw err;
  })
})

//List one book from DB based on the id
app.get("/books/:id", (req,res)=>{
 // res.send(req.params.id) //send the book id as parameter http://localhost:4545/books/1234
  BookModel.findById(req.params.id).then((book) =>{
    
    if(book) //if book exists //http://localhost:4545/books/5f9185db5b2e61576c74fc98
    {
       res.json(book)
    }
    else{
     res.sendStatus(404);
    }
  }).catch(err =>{
            throw err;
  })

})

//List the book by its title
/*app.get("/books/:title", (req,res)=>{
  // res.send(req.params.id) //send the book id as parameter http://localhost:4545/books/1234
   BookModel.find(req.params.title).then((book) =>{
     
     if(book) //if book exists //http://localhost:4545/books/The exorcist
     {
        res.json(book)
     }
     else{
      res.sendStatus(404);
     }
   }).catch(err =>{
             throw err;
   })
 
 })*/

 //Delete book entries by its Id
//Delete in Postman : http://localhost:4545/book/5f9185db5b2e61576c74fc98
 app.delete("/book/:id" , (req,res) =>{
   BookModel.findOneAndRemove(req.params.id).then(() =>{
     res.send("book deleted by its id")
   }).catch(err=>{
       throw err;
   })

 })

app.listen(4545, ()=> { 
  console.log("Books service is running");
  
})