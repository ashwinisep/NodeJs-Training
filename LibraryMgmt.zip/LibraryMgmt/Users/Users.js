const express = require('express') //include express

const app = express() //instance of express

const mongoose  = require('mongoose') 

const bodyparser = require("body-parser")
app.use(bodyparser.json()); //Retrieves and parses the json request body


//connect to UsersService db
mongoose.connect("mongodb+srv://mongodb:Cel%401234@cluster0.envdo.mongodb.net/UsersService" , { useNewUrlParser: true , useUnifiedTopology: true}, ()=>{ 
  console.log("UsersService -database connected successfully");
});

//Load the 'UserModel'
require('./UserModel')

//Create a Model instance
const varUserModel = mongoose.model("UserModel")

//Post method : To create users and save it the table http://localhost:4546/User
app.post("/User" , (req,res) =>{
    //console.log(req.body); //print the request sent from postman in the console here
    var newUser = {
        name: req.body.name,
        userid:req.body.userid,
        email:req.body.email
    }

    var Userinst= new varUserModel(newUser)

    Userinst.save(function (err, data) {
        console.log("New User created and saved");//UsersService/usermodels table will be created
        
      })

    res.send("Response - New user created successfully");//send the response back
})

//Get method :http://localhost:4546/users in postman
//Finds all the Users 
app.get("/users" , (req,res) =>{
    varUserModel.find().then( (users)=>{
        //console.log(users) //print in console here
        res.json(users);//show the json content in the web page http://localhost:4546/users
      }).catch(err =>{
             if(err)
              throw err;
      })
})

//Get method:
//Find the users by id
//id is the _id column created in the table.
app.get("/users/:id", (req,res)=>{
    // res.send(req.params.id)
    varUserModel.findById(req.params.id).then((users) =>{
       
       if(users) //if book exists //http://localhost:4546/users/5f92cde8adfa953c206f84c4
       {
          res.json(users)
       }
       else{
        res.sendStatus("Invalid id")
       }
     }).catch(err =>{
           if(err)
               throw err;
     })   
   })


//Delete Users by its Id
//browser isnt capable of testing delete ,hence test in postman
//Delete in Postman : http://localhost:4546/users/5f92cde8adfa953c206f84c4
app.delete("/users/:id" , (req,res) =>{
  varUserModel.findById(req.params.id).then(() =>{
    res.send("User deleted by its id")
  }).catch(err=>{
    if(err)
      throw err;
  })

})  

app.listen("4546", () =>{
    console.log("Users service is running on port 4546")
})