 const express = require('express') //include express

const app = express() //instance of express

const mongoose  = require('mongoose') 

const bodyparser = require("body-parser")
app.use(bodyparser.json()); //Retrieves and parses the json request body


const axios = require('axios');
const http = require('http')
const { response } = require('express');


//connect to UsersService db
mongoose.connect("mongodb+srv://mongodb:Cel%401234@cluster0.envdo.mongodb.net/OrdersService" , { useNewUrlParser: true , useUnifiedTopology: true}, ()=>{ 
  console.log("OrdersService -database connected successfully");
}); 


//Include the model file
require('./Order') //Include Order.js

//Load the Model
const OrderModel = mongoose.model("Order")

//Create a new Order using POST
//Postman: http://localhost:4547/Orders
app.post("/Orders" ,(req,res)=>{

    var newOrder ={
        UserId:mongoose.Types.ObjectId(req.body.UserId), //convert string to Object Id before save in DB
        BookId :mongoose.Types.ObjectId(req.body.BookId),
        BorrowedDate:req.body.BorrowedDate,//yyyy-mm-dd
        LendDate:req.body.LendDate
    }

    var newOrderInst = new OrderModel(newOrder);

    newOrderInst.save(function (err, data) {
        //console.log("New Order created and saved");//OrdersService/OrderModel table will be created
        res.send("New Order created and saved successfully")
      })

    res.send("Response - New Order created successfully");//send the response back

})

//Get List of Orders
//Postman: http://localhost:4547/orders
app.get("/Orders" ,(req,res)=>{

    OrderModel.find().then((books) => {
          res.json(books)
    }).catch((err) =>{
        {
            if(err)
            throw err;
        }
   })
})


//List Orders by its Id and display the users name and book title
//Hence modify the book.js and user.js to fetch the booktitle and users name
//npm install --save axios This is a library executed to make http request to other existing HTTP service [user,books service]
app.get("/orders/:id" ,(req,res)=>{
     OrderModel.findById(req.params.id).then((order)=>{
        if(order) //If order is present in DB,check in DB if it is present
        {
            console.log("Valid Order")
             //Users service,concatenate with the UserId 
             axios.get("http://localhost:4546/users/" +mongoose.Types.ObjectId(order.UserId)).then((response)=>
            {
                console.log(response) //Log the response from Users service here
                //Get the user name and booktitle which is empty for now coz book service has to be invoked
                var orderObj = { name:response.data.name , booktitle:''}

                //call books service
                axios.get("http://localhost:4545/books/"+orders.BookId).then((response) =>
                {
                    orderObj.booktitle = response.data.booktitle;
                     res.json(orderObj)
                }).catch((err)=>{
                    console.log('error is ', err)
                })
           }).catch((err)=>{
               if (err)
               console.log('error is ', err)
           })
           //res.send("Response from Users service")
        }
        else{
            res.send("Invalid order")
        }
          
    }) 
})


//Listen On Port
app.listen("4547",() =>{
    console.log("Orders service is running on port 4547")
})