const mongoose = require ('mongoose');

//Model class or Data class or the file that contains the data for the bookservice
mongoose.model("Book" ,{
    //Title,Author,NumOfPages,Publisher 
    title:{
        type:String,
        require :true //it is required,mandatory
    },

    author :{
        type:String,
        require: true
    },

    NumOfPages:
    {
        type:Number,
        require:true
    },

    publisher:
    {
        type:String,
        require:false
    }
} );