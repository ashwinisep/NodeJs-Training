const mongoose = require('mongoose')

/*Define the Orders Model fields
It contains
1. UserId, to identify which User borrowed the book from the library
2. BookId, to identify the bookId borrowed from the library
3 .BorrowedDate :
4 .LendDate:*/
mongoose.model('Order' , {
    UserId:{
        type: mongoose.SchemaTypes.ObjectId, //To hold mongo DB datatype
        required: true
    },
    BookId: {
        type: mongoose.SchemaTypes.ObjectId,
        required: true
    },
    
    BorrowedDate :{
        type: Date,
        required: true
    },

    LendDate:{
        type: Date,
        required: true 
    }
})